package com.itbank.model;

public class BiznoDTO {
		
	private String bizrno;

	public String getBizrno() {
		return bizrno;
	}

	public void setBizrno(String bizrno) {
		this.bizrno = bizrno;
	}
	
	

}
