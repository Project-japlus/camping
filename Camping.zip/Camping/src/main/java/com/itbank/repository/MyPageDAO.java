package com.itbank.repository;

import com.itbank.model.UserDTO;

public interface MyPageDAO {

	UserDTO checkLogin(UserDTO dto);


	
}
