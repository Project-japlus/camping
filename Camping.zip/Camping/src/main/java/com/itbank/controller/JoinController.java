package com.itbank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.model.BiznoDTO;
import com.itbank.model.UserDTO;
import com.itbank.repository.UserDAO;
import com.itbank.service.UserService;

@Controller
public class JoinController {

	@Autowired private UserService campingService;
	@Autowired private UserDAO userDAO;


	@GetMapping("user_join")
	public void user_join() {}
	
	@GetMapping("bizr_join")
	public void bizr_join() {}
	
	@PostMapping("/user_join")
	public String user_join(UserDTO dto) {
		int row = campingService.join_user(dto);
		System.out.println("일반" + row + "행이 추가되었습니다");
		return "redirect:/";
	}
	
	@PostMapping("/bizr_join")
	public String bizr_join(UserDTO dto) {
		int row = campingService.join_bizr(dto);
		System.out.println("사업자" + row + "행이 추가되었습니다");
		return "redirect:/";
	}
	
	@GetMapping("bizrno")
	public ModelAndView bizrno(BiznoDTO bdto){
		ModelAndView mav = new ModelAndView();
		List<BiznoDTO> list = userDAO.getbizno(bdto);
		mav.addObject("bizno", list);
		return mav;
	}
	
	
}
