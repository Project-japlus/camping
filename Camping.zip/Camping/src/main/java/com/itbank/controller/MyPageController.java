package com.itbank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.component.HashComponent;
import com.itbank.model.UserDTO;
import com.itbank.service.UserService;

@Controller
public class MyPageController {

	@Autowired private HashComponent hashComponent;
	@Autowired private UserService userService;
	
	@GetMapping("/Mypage_check")
	public void MyPage_check() {}
	
	@PostMapping("/Mypage_check")
	public String MyPage_check(UserDTO dto, HttpSession session) {
		// 세션에서 가져온 로그인된 유저 정보
		UserDTO info_login = (UserDTO) session.getAttribute("login");
		//해쉬처리된 입력한 패스워드
		String hash_inputpw = hashComponent.getHash(dto.getUserpw(), info_login.getSalt());
		// 세션의 패스워드
		String session_pw = info_login.getUserpw();
		// 해쉬처리된 입력한 패스워드 와 세션의 비밀번호가 같으면 Mypage로 돌리고 아니면 홈으로 돌리기
		if(hash_inputpw.equals(session_pw)) {
			return "redirect:/Mypage";
		}else {
			return "redirect:/Mypage_check";
		}
	}
	
	@GetMapping("/Mypage")
	public ModelAndView Mypage(HttpSession session) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("login", session.getAttribute("login"));
		return mav;
	}
	
	
	@GetMapping("/Mypage_modify")
	public String Mypage_modify(HttpSession session) {
		UserDTO login = (UserDTO) session.getAttribute("login");
		session.setAttribute("login", login);
		return "Mypage_modify";
	}
	
	
	//MyPageContorller 에서 솔트랑 비밀번호 받아서 해시처리 해주는 함수
	@GetMapping("/Mypage_modify_hash")
	@ResponseBody
	public String Mypage_modify_hash(String now_pw, String session_salt) {
		// session_salt 매개변수를 담을 salt 함수 선언
	    String salt = session_salt;
	    
	    // now_pw랑 salt를 now_password_hash 로 담아서 해쉬처리 
	    String now_password_hash = hashComponent.getHash(now_pw, salt);
	    
	    // 그값 반환
	    return now_password_hash;
	}
	
	// 일반 사용자비밀번호를 수정할 함수
	@PostMapping("modify_userpw")
	public String Mypage_modify_password(UserDTO dto, HttpSession session) {
		System.out.println("값 넘어옴");
		System.out.println("넘어온 user_idx = " + dto.getUser_idx());
		System.out.println("넘어온 userpw = " + dto.getUserpw());
		int row = 0;
		
		//UserDTO 타입의 로그인 이란 이름이 변수 선언 (세션에서 로그인 정보 가져오고)
		UserDTO login = (UserDTO) session.getAttribute("login");
		// login 에서 bizrno 번호 가져오기
		String bizrno = login.getBizrno();
		
		System.out.println(bizrno);
		
		// 만약 사업자 번호가 null 이면 일반 사용자 비번 수정
		if(bizrno == null) {
			row = userService.user_modify_pw(dto);
		}else {
			// 만약 사업자 번호가 null 이 아니면  일반 사용자 비번 수정
			row = userService.bizr_modify_pw(dto);
		}
		System.out.println(row + "행 업데이트 성공.");
		return "Mypage_modify";
	}
	
	
	
	

}

