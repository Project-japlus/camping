package com.itbank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.itbank.component.HashComponent;
import com.itbank.model.UserDTO;

@Controller
public class MyPageController {

	@Autowired private HashComponent hashComponent;
	
	@GetMapping("/Mypage_check")
	public void MyPage_check() {}
	
	@PostMapping("/Mypage_check")
	public String MyPage_check(UserDTO dto, HttpSession session) {
		// 세션에서 가져온 로그인된 유저 정보
		UserDTO info_login = (UserDTO) session.getAttribute("login");
		//해쉬처리된 입력한 패스워드
		String hash_inputpw = hashComponent.getHash(dto.getUserpw(), info_login.getSalt());
		// 세션의 패스워드
		String session_pw = info_login.getUserpw();
		// 해쉬처리된 입력한 패스워드 와 세션의 비밀번호가 같으면 Mypage로 돌리고 아니면 홈으로 돌리기
		if(hash_inputpw.equals(session_pw)) {
			return "redirect:/Mypage";
		}else {
			return "redirect:/Mypage_check";
		}
	}
	
	@GetMapping("/Mypage")
	public ModelAndView Mypage(HttpSession session) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("login", session.getAttribute("login"));
		return mav;
	}
	
	@GetMapping("/Mypage_modify")
	public void Mypage_modify() {}
	
	
	
	
	

}

